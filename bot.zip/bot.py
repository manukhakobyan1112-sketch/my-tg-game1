import asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.types import WebAppInfo, InlineKeyboardMarkup, InlineKeyboardButton

# 1. СЮДА ВСТАВЬ СВОЙ ТОКЕН (API Token)
TOKEN = "8327543648:AAGVnothYazhfs5d5h00ThW2q8j8YYZSYi8"

# 2. СЮДА ВСТАВЬ ССЫЛКУ НА ИГРУ (пока можно оставить эту для теста)
# Когда сделаешь ссылку через GitHub или ngrok, замени её здесь
GAME_URL = "https://www.google.com" 

bot = Bot(token=TOKEN)
dp = Dispatcher()

@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    # Создаем красивую кнопку под сообщением
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(
                text="Открыть мою игру 🎮", 
                web_app=WebAppInfo(url=GAME_URL)
            )
        ]
    ])
    
    await message.answer(
        f"Привет, {message.from_user.first_name}! 👋\n\n"
        "Я твой игровой бот. Нажми на кнопку ниже, чтобы запустить игру прямо здесь!",
        reply_markup=markup
    )

async def main():
    print("✅ Бот успешно запущен и ждет команд в Telegram!")
    await dp.start_polling(bot)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception as e:
        print(f"❌ Ошибка: {e}")